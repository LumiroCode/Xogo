# RTS AI — modularny renderer 2D isometric

Prototyp warstwy prezentacji dla RTS-a. Runtime używa Canvas 2D i danych JSON; logika gry pozostaje oddzielona od renderera.

## Najważniejsza zmiana

Jednostki nie mają już pojedynczego `visual: "mech"`. Wygląd powstaje z tego samego trójpodziału co definicja MVP:

```text
platform + weapon + specialization
```

`src/engine/ModularSpriteComposer.js` składa trzy warstwy przez sockety montażowe i cache'uje wynik. Aktualne definicje zawierają 5 platform, 7 broni i 6 specjalizacji, czyli 210 możliwych kompozytów przy zaledwie 18 SVG proxy.

## Uruchomienie

```bash
python serve.py
```

- gra/test: `http://127.0.0.1:8765/`
- pełna macierz modułów: `http://127.0.0.1:8765/gallery.html`

## Sterowanie

- LPM — wybór jednostki ludzi,
- PPM — ruch,
- Shift+LPM lub środkowy — kamera,
- kółko — zoom,
- WASD / strzałki — kamera,
- V — sensory,
- G — siatka,
- H — wysokość,
- F — fog of war.

## Dane

- `data/unit_definitions.json` — dostarczony schemat `0.3-mvp`,
- `data/terrain_presets.json` — dostarczony schemat terenu `0.1-mvp`,
- `data/demo_units.json` — instancje demo; osiem oficjalnych konfiguracji + trzy nowe kombinacje AI,
- `data/map.json` — mapa używająca `open`, `road`, `vegetation`, `ruins`, `soft_ground`, `rough_ground`,
- `data/assets.json` — wyłącznie kontrakt wizualny: pliki modułów, sockety, mount-pointy i style terenu.

## Architektura

```text
simulation / ML / MVP
        │
        │ snapshot/delta state
        ▼
GameViewAdapter
        │
        ▼
Scene ──→ IsoRenderer
           │
           ├─ ModularSpriteComposer
           │    └─ platform + specialization + weapon → cached Canvas
           │
           ├─ terrain/elevation
           ├─ FOW / contacts / last-known
           └─ picking / camera
```

Renderer nie zna `damage`, `armor`, `suppression`, logistyki ani AI. Zna tylko identyfikatory modułów potrzebne do ich przedstawienia.

## Proxy i docelowe assety

`assets/modules/` zawiera własne SVG proxy:

- `platforms/` — 5,
- `weapons/` — 7,
- `specializations/` — 6.

W przyszłości można podmienić pojedyncze moduły na prerenderowane PNG/WebP z Quaterniusa. Nie trzeba renderować osobno każdej konfiguracji; `gallery.html` służy do kontroli całej macierzy po każdej podmianie.
