# Integration contract: game logic → modular renderer

Renderer jest klientem stanu gry. Nie wykonuje pathfindingu, combat resolution, sensor resolution, supply ani AI.

## Encja modularna

Logika publikuje **identyfikatory montażu**, nie ścieżki do sprite'ów:

```js
view.spawnEntity({
  id,
  visual: {
    kind: 'modular_unit',
    platform: 'light_tracked',
    weapon: 'autocannon',
    specialization: 'signature_reduction_package'
  },
  x, y, z, faction, hp, maxHp, sensorRange, visibility
});
```

Nazwy `platform`, `weapon` i `specialization` odpowiadają definicjom logiki, ale renderer używa ich wyłącznie jako kluczy prezentacyjnych. Nie odczytuje statystyk modułów.

## Automatyczna kompozycja

`ModularSpriteComposer`:

1. pobiera SVG platformy,
2. odczytuje sockety platformy z `data/assets.json`,
3. montuje specialization,
4. montuje weapon,
5. zapisuje wynik do offscreen Canvas,
6. cache'uje wynik pod `platform|weapon|specialization`.

Nie istnieje asset „tracked_artillery.svg” ani „assault_walker.svg”. Konfiguracje powstają w runtime.

Przy obecnym katalogu 5 platform × 7 broni × 6 specjalizacji renderer potrafi złożyć 210 kombinacji bez dodatkowego kodu. `gallery.html` renderuje wszystkie jako test regresji.

## Pozostały kontrakt

```js
view.setMap(mapPresentation);
view.spawnEntity(viewState);
view.updateEntity(id, { x, y, z, hp });
view.setVisibility(id, 'visible' | 'contact' | 'lastKnown' | 'hidden');
view.setSelection(ids);
view.removeEntity(id);
view.render({ fog, commandMarker });
```

Symulacja pozostaje autorytatywna i może publikować delta state po ticku. Renderer działa w `requestAnimationFrame` i nie powinien otrzymywać pojęć takich jak `damage`, `suppression`, `supply route` czy `AI policy`.
